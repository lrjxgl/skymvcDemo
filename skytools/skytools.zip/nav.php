<style type="text/css">
.nav{width:800px; margin:0 auto; margin-bottom:10px;}
.nav a{display:inline-block; padding:0px 6px; height:30px; line-height:30px; background-color:#FC6; text-decoration:none; color:white;}
pre{border: 4px solid rgb(156, 235, 235);display: block;padding: 10px;}
</style>
<div class="nav">
<a href="control.php">生成控制器</a>
<a href="modulecontrol.php">生成模块控制器</a>
<a href="sqlform.php">表单处理</a>

<a href="sqllist.php">列表处理</a>
<a href="sqlshow.php">详细页处理</a>
<a href="sqlpost.php">保存处理</a>
 

<a href="sqlinsert.php">测试数据</a>

</div>